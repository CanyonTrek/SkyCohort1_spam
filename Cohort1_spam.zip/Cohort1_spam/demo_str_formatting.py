#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will show you different ways of
# formatting strings.
"""
    DocString:
"""
# Dict of planetory name and distance to SUN in Giga metres.
planets = {'Mercury': 57.91,
           'Venus': 108.2,
           'Earth': 149.597870,
           'Mars': 227.94
}

# ITERATE through the planets and display info using
# ITERATOR for loop plus, str concatenation and escape chars. UGLY!
for planet in planets:
    print("\t\t" + planet + ": \t" + str(planets[planet]) + " Gm\t" + str(hex(0xff)))

print("-" * 40)
# ITERATOR for loop plus, str concatenation and str justification methods. OK!
for planet in planets:
    print(planet.rjust(12) + ": " + str(planets[planet]).center(12, '.')
          + " Gm " + str(hex(0xff)).rjust(6))

print("-" * 40)
# ITERATOR for loop plus and the str .format() method. Good!
for planet in planets:
    print("{0:>12s}: {1:.^12.3f} Gm {2:#6x}".format(planet, planets[planet], 0xff))

print("-" * 40)
# ITERATOR for loop plus and the f-strings (Py3.5 onwards. Better :-)!
for planet in planets:
    print(f"{planet:>12s}: {planets[planet]:.^12.3f} Gm {0xff:#6x}")