#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This is an ultra realistic game with Tanks!
"""
    GOT - Game of Tanks!
"""

import tank


# Instantiate/Create three new Tank objects!
sam_tank = tank.Tank('German', 'Tiger')
sofia_tank = tank.Tank('American', 'Sherman')
lidia_tank = tank.Tank('British', 'Churchill')

# And the game begins...
sam_tank.accel(43)
sofia_tank.accel(31)

lidia_tank.rotate_left(285)
lidia_tank.accel(38)
lidia_tank.shoot()

# And success..
sam_tank.take_damage(62)
sofia_tank.take_damage(28)

# And now for some visuals.
# print(f"Health of Sam's tank is {sam_tank._health}") # POOR CODE!

print(f"Health of Sam's and Sofia's Tanks = {sam_tank + sofia_tank}")

# Sam's Tank has received a Health Boost!
# sam_tank._health = 99 # Example of POOR CODE!
# print(f"Sam's new health = {sam_tank._health}") # Example of POOR CODE!
sam_tank.set_health(101) # Example of a Setter method.
print(f"Sam's new health = {sam_tank.get_health()}") # Example of a GETTER method.

sam_tank.tank_health = 102 # Example of a Setter method.
print(f"Sam's new health = {sam_tank.tank_health}") # Example of a GETTER method.

print(f"Status of Sam's Tank is {sam_tank}")