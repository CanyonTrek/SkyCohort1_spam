#! /usr/bin/env python3
# Name:        tank.py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This module describes a Class of Tank
"""
    Tank Class
"""

class Tank:
    # Class has attributes/Data and behaviour/methods.
    def __init__(self, country, model):
        """ Constructor - Create a new Tank object. """
        self.country = country
        self.model = model
        self._speed = 0
        self._direction = 0
        self._location = {'x':0, 'y':0, 'z':0}
        self._shells = 20
        self._health = 100
        # No explicit Return as called implicitly

    def accel(self, increase):
        self._speed += increase
        return None

    def decel(self, decrease):
        self._speed -= decrease

    def rotate_left(self, degrees):
        self._direction -= degrees % 360
        return None

    def rotate_right(self, degrees):
        self._direction += degrees % 360
        return None

    def shoot(self):
        self._shells -= 1
        return None

    def take_damage(self, amount):
        self._health -= amount
        return None

    # Some special Methods...

    # Example of Operator Overloading.
    def __add__(self, other):
        return self._health + other._health

    # Example of DUCK Typing, Our Tank objects can now QUACK like a str!
    def __str__(self):
        return f"Model={self.model}, Health={self._health}, Speed={self._speed}"


    # Example of a Getter Method.
    def get_health(self):
        return self._health

    # Example of a Setter Method.
    def set_health(self, newhealth):
        self._health = newhealth
        return None

    # Property built-in function wraps two other functions with one
    # variable name interface
    # tank_health = property(get_health, set_health)

    # Decorate tank_health with other property function!
    @property
    def tank_health(self):
        return self._health

    # Example of DECORATORS!
    @tank_health.setter
    def tank_health(self, newhealth):
        self._health = newhealth
        return None