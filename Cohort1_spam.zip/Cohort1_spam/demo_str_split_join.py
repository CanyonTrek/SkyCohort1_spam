#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to split and rejoin strings
# using the .split() and .join() str methods.
"""
    DocString:
"""
# Sample line from /etc/passwd on Linux for the root user.
line = "root:x:0:0:The Super User:/home:/bin/ksh"
print("Original: ", line)
# I want to EDIT the str! str are IMMUTABLE!
# But we could split the string into a LIST.
fields = line.split(":") # Return a list (mutable)
fields[4] = "The administrator"
fields[6] = "/bin/bash"

line = ":".join(fields) # Return a str.
print("Modified: ", line)