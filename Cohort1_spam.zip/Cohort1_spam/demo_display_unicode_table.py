#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will display all the chars in the
# unicode table 0>65536 using an ITERATOR for loop plus the
# built-in chr() function.
"""
    DocString:
"""
import sys

# Iterate through all the Unicode char postions.
for pos in range(0, 65536, 1):
    try:
        print(chr(pos), end=" ")
        if pos % 16 == 0:
            print()
    except UnicodeEncodeError:
        print(" ")

print(sys.getdefaultencoding())