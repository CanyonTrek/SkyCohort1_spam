#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to match and modify (substitute) a
# string using Regex and the re.sub() method.
"""
    DocString:
"""
import re

# Sample line from /etc/passwd on MacOSX for the root user login.
line = "root:x:0:0:The Super User:/root:/bin/ksh"

line = re.sub(r"[sS]uper [uU]ser", r"Administrator", line) # Returns Modified str.
line = re.sub(r"ksh$", r"bash", line) # Returns Modified str.

print(f"Modified line={line}")