#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will generate 6 UNIQUE random
# lottery numbers
"""
    DocString:
"""
import random

# lotto = [] # Empty list.

# Repeat whilst less than 6 numbers.
# while len(lotto) < 6:
#    num = random.randint(1, 50)
#    if num not in lotto:
#        lotto.append(num)
#    else:
#        print("Duplicate number=", num)

# A more PYTHONIC solution!
lotto = set() # Empty set.
while len(lotto) < 6:
    num = random.randint(1, 50)
    lotto.add(num)

print("Lottery numbers=", sorted(lotto))