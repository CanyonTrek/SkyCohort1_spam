#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to open/close file handle for
# RANDOM read and write.
"""
    DocString:
"""
SOF = 0 # Start of File
CUR = 1 # Current file position
EOF = 2 # End of File

# Open file handle for READING in TEXT mode
with open(r"c:\labs\projects\Cohort1_spam\movies.txt", mode="rt") as fh_in:
    fh_in.seek(90, SOF)
    text = fh_in.read(30)
    print(f"Text at {fh_in.tell() - len(text)} = {text}")

    fh_in.seek(120, SOF)
    text = fh_in.read(30)
    print(f"Text at {fh_in.tell() - len(text)} = {text}")

# Open file handle for READING in binary/bytes mode
with open(r"c:\labs\projects\Cohort1_spam\movies.txt", mode="rb") as fh_in:
    fh_in.seek(-100, EOF) # Seek back 90 chars from EOF
    text = fh_in.read(30)
    print(f"Text at {fh_in.tell() - len(text)} = {text}")

    fh_in.seek(-40, CUR) # Seek back 40 chars from current byte position.
    text = fh_in.read(30)
    print(f"Text at {fh_in.tell() - len(text)} = {text}")