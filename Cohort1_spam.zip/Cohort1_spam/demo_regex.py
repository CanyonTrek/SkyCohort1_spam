#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to match lines of data from a
# file using Regular Expressions/Regex and the re.py module.
"""
    DocString:
"""
import re
# open file handle for READING in TEXT mode.
fh_in = open(r"c:\labs\words", mode="rt")

# Iterate through filehandle one line at a time using an
# ITERATOR for loop.
for line in fh_in:
    # Example of str matching.
    # if line.startswith("Y") and line.rstrip("\n").endswith("n") and "town" in line:
    # m = re.search(r"^the", line) # Match lines starting with 'the'
    # m = re.search(r"ing$", line) # Match lines ending with 'ing'
    # m = re.search(r"^ring$", line)  # Match lines with only 'ring'
    # m = re.search(r"^[adpr]ing$", line)  # Match lines starting with [adpr] and 'ing'
    # m = re.search(r"^...................$", line) # Match lines with exactly 19 chars.
    # m = re.search(r"^.{19}$", line) # Match lines with exactly 19 chars.
    # m = re.search(r"^...................", line)  # Match lines with at least 19 chars.
    # m = re.search(r"^[A-Z]", line) # Match lines starting with a capital.
    # m = re.search(r"[0-9][0-9]", line) # Match lines with 2 consecutive digits.
    # m = re.search(r"[aeiou][aeiou][aeiou]", line) # Match lines 3 consecutive vowels.
    m = re.search(r"[aeiou]{5,}", line) # Match lines with at least 5 consecutive vowels.
    # m = re.search(r"\.", line) # Match lines with a dot.
    # m = re.search(r"^[A-Z].*[A-Z]$", line)  # Match lines start/end with capital.
    # m = re.match(r"^[A-Z].*[A-Z]$", line)  # Auto matches lines starting with!.
    # m = re.fullmatch(r"^.{19}\n$", line) # Fullmatch must match ENTIRE line incl '\n'.
    # m = re.search(r"^[A-Z]", line, flags=re.IGNORECASE) # Match lines starting with a capital.
    # m = re.search(r"^(.)(.).\2\1$", line) # Match lines with exactly 5 char palindromes.
    # m = re.search(r"^([A-Z]).*\1$", line) # Match lines start/end with same capital!
    if m:
        print(f"Matched {m.group()} on line {line.rstrip()} at {m.start()}-{m.end()}")

fh_in.close() # Close file handle.