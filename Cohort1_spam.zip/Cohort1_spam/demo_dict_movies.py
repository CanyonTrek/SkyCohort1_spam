#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to create, grow and
# shrink a dict (MUTABLE collection of objects with Unique keys).
# Py 3.6 onwards -> Insertion Order.
"""
    DocString:
"""
import pprint

# A multi-dimensional dict of lists!
movies = { 'sam': ['princess diaries', 'star wars', 'matilda'],
           'lidia': ['blue beetle', 'gran turismo', 'avengers end game'],
           'lousie': ['spiderman', 'grease', 'sound of music']
}

# Grow the dict.
movies['donald'] = ['braveheart', 'brave', 'babe']

# Shrink the dict.
# movies.pop('sam') # Remove key+value pair.
movies.popitem() # Remove last key+value pair inserted!

# films = movies.copy() # Copy dict.
# movies.clear() # Empties dict.
# pprint.pprint(movies)

print(f"Sam's favourite movies = {movies['sam']}")
print(f"Sam's favourite movie = {movies['sam'][0]}")
print("-" * 60)

# ITERATE through the keys using an ITERATOR for loop
# plus .keys() method.
for name in movies.keys():
    print(f"{name} likes {movies[name]}")

# ITERATE through the values using an ITERATOR for loop
# plus .values() method.
for films in movies.values():
    print(f"We like {films}")

# ITERATE through the keys+values using an ITERATOR for loop
# plus .items() method (returns TUPLE).
for (name, films) in movies.items():
    print(f"{name} loves {films} ")