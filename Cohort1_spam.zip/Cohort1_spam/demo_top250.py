#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program 
"""
    DocString:
"""

fh_in  = open(r"c:\labs\top_250.txt", mode="rt")

for (rank, line) in enumerate(fh_in, start=1):
    print(rank, line, end="")

fh_in.close()