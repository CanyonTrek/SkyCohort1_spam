#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to ITERATE
# through sequences (str/tuple/list/sets/dicts) using
# an ITERATOR for loop.
"""
    DocString:
"""
#               0                1          2           3
heroes = ['winnie the pooh', 'big ange', 'parents', 'beyonce',
          'billy connolly', 'william wallace']

# ITERATE through the heroes one object at a time using
# an ITERATOR for loop.
for name in heroes:
    print(name.title(), end="\n")
print("Our heroes are:", heroes)

# ITERATE through the SEQUENCE one object at a time using
# an ITERATOR for loop and MODIFY each one.
idx = 0
for name in heroes:
    print(name.title(), end="\n")
    heroes[idx] = name.title()
    idx += 1
print("Our heroes are:", heroes)

# ITERATE through the SEQUENCE one object at a time using
# an ITERATOR for loop and MODIFY each one USING the built-in
# enumerate() function.
for (idx, name) in enumerate(heroes, start=0):
    print(name.upper(), end="\n")
    heroes[idx] = name.upper()
print("Our heroes are:", heroes)