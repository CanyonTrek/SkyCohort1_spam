#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to define a Variadic Function
# which accepts a variable number of parameters.
"""
    A collection of functions for searching for Regex patterns in files
"""
import re

# Example of a Variadic user function with parameter passing and defaults
# which allows variable number of parameters unpacked into a TUPLE.
def search_pattern(pattern:str=r"^.{19}$", *files)->int:
    """ Search for a Regec in multiple files and return num lines matched """
    lines = 0
    for file in files:
        # open file handle for READING in TEXT mode.
        with open(file, mode="rt") as fh_in:
            for line in fh_in:
                m = re.search(pattern, line) # Match lines with at least 5 consecutive vowels.
                if m:
                    lines += 1
                    print(f"Matched {m.group()} on line {line.rstrip()} at {m.start()}-{m.end()}")

    return lines

num_lines = search_pattern(r"^([A-Z]).*\1$", r"c:\labs\words", r"c:\labs\words2")
print(f"Number of lines matched = {num_lines}")