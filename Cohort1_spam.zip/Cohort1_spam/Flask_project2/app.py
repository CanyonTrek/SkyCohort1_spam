#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program 
"""
    DocString:
"""

from application import app

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0') # Run on all addresses.