#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program 
"""
    DocString:
"""

from flask import render_template
from application import app # Gosh Circular Imports!

@app.route('/')
@app.route('/home')
def template_home():
    return render_template('home.html', title='Home')

@app.route('/welcome/<string:name>')
def template_base(name):
    return render_template('base.html', name=name, group='Sky Grads')

@app.route('/movies/')
def movies():
    movies = []
    fh_in = open(r"c:\labs\top_250.txt")
    for film in fh_in:
        movies.append(film)
    return render_template('movies.html', title='Movies', movies=movies)