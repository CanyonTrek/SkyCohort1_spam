#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program 
"""
    DocString:
"""

from flask import Flask

# Instantiate/Create new Flask object (web server).
app = Flask(__name__)

# Gosh Circular Imports but its
# ok as we are not using routes in __init__.py and just making
# sure we import modules (at bottom of file).
from application import routes
