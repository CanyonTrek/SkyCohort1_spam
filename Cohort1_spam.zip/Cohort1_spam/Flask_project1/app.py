#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program 
"""
    DocString:
"""
from flask import Flask, Response, request, url_for

# Instantiate/create a Flask Object
app = Flask(__name__)

@app.route('/', methods=['GET'])
def hello_from_Flask():
    return "Hello from Flask"

@app.route('/sky', methods=['GET'])
def hello_grads():
    return "Hello Sky Grads"

@app.route('/get/text', methods=['GET'])
def get_text():
    return Response("Hello from Flask using an explicit Response", mimetype='text/plain')

@app.route('/post/text', methods=['POST'])
def post_text():
    data_sent = request.data.decode('utf-8')
    return Response(f"You posted this to the Flask app: {data_sent}", mimetype='text/plain')

# Create Dynamic Routes
@app.route('/name/<string:name>')
def say_hello(name):
    return f"Hello {name}"

@app.route('/square/<int:number>')
def square(number):
    return f"Your number squared is {number ** 2}"

@app.route('/welcome/<string:name>')
def welcome(name):
    return f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <title>Sample - Flask routes</title>
    </head>
    <body>
        <h1>Name Page</h1>
        <p>Hello {name}!</p>
    </body>
    </html>
    """

@app.route('/index/<string:name>/<int:age>')
def index(name, age):
    url = url_for('get_text')
    return f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <title>Sample - Flask routes</title>
    </head>
    <body>
        <h1>Name Page</h1>
        <p>Hello {name}!</p>
        <p>You are {age} year(s) old.</p>
        <hr>
        <a href="{url}">Welcome</a>
    </body>
    </html>
    """


if __name__ == "__main__":
    # Execute only if ran directly as a Program
    # Ignore if imported as a module.
    app.run(debug=True)