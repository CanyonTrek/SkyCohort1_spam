#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to match lines of data from a
# file using Regular Expressions/Regex and the re.py module.
"""
    DocString:
"""
import re
# open file handle for READING in TEXT mode.
fh_in = open(r"c:\labs\words", mode="rt")

reobj = re.compile(r"^.{19}$") # Precompile pattern ONCE! PERFORMANCE IMPROVEMENT!

for line in fh_in:
    # m = re.search(r"[aeiou]{5,}", line) # Match lines with at least 5 consecutive vowels.
    m = reobj.search(line)  # Match lines with at least 5 consecutive vowels.
    if m:
        print(f"Matched {m.group()} on line {line.rstrip()} at {m.start()}-{m.end()}")

fh_in.close() # Close file handle.