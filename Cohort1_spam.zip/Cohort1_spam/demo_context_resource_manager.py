#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to open and automatically close
# file handles using a with statement = Context Resource Manager
"""
    DocString:
"""
import sys
movies = { 'sam': ['princess diaries', 'star wars', 'matilda'],
           'lidia': ['blue beetle', 'gran turismo', 'avengers end game'],
           'louise': ['spiderman', 'grease', 'sound of music'],
           'donald': ['braveheart', 'brave', 'babe']
}

# Open File Handle for WRITING in TEXT mode.
with open(r"c:\labs\projects\Cohort1_spam\movies.txt", mode="wt") as fh_out:
    for name in movies.keys():
        print(f"{name}: {movies[name]}", end="\n", file=sys.stdout)
        print(f"{name}: {movies[name]}", end="\n", file=fh_out)
        # fh_out.write(f"{name}: {movies[name]}\n")

print("-" * 60)

# Open file handle for READING in TEXT mode.
with open(r"c:\labs\projects\Cohort1_spam\movies.txt", mode="rt") as fh_in:
    for line in fh_in:
        print(line, end="")
    # End of block scope, fh_in closed.

print("Normal output, send to stdout", file=sys.stdout)
print("Error output, send to stderr", file=sys.stderr)