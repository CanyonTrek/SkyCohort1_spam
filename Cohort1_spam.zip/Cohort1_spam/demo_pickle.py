#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to PRESERVE
# ONE Python object (data+structure) to a file using
# the pickle module.
"""
    DocString:
"""
import pickle
import pprint
import gzip

movies = { 'sam': ['princess diaries', 'star wars', 'matilda'],
           'lidia': ['blue beetle', 'gran turismo', 'avengers end game'],
           'louise': ['spiderman', 'grease', 'sound of music'],
           'donald': ['braveheart', 'brave', 'babe']
}

# Open file handle for WRITING in BYTES/BINARY mode.
# with open(r"c:\labs\projects\Cohort1_spam\movies.p", mode="wb") as fh_out:
with gzip.open(r"c:\labs\projects\Cohort1_spam\movies.pgz", mode="wb") as fh_out:
    # pickle.dump(movies, fh_out, protocol=5) # Pickle protocol (0-5, 0=ascii, 1-5=binary)
    # pickle.dump(movies, fh_out, protocol=pickle.DEFAULT_PROTOCOL) # Default 5
    pickle.dump(movies, fh_out, protocol=pickle.HIGHEST_PROTOCOL)

# Open file handle for READING in BYTES/BINARY mode.
# with open(r"c:\labs\projects\Cohort1_spam\movies.p", mode="rb") as fh_in:
with gzip.open(r"c:\labs\projects\Cohort1_spam\movies.pgz", mode="rb") as fh_in:
    films = pickle.load(fh_in)

pprint.pprint(movies)
print("-"  * 60)
pprint.pprint(films)

