#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to define, name, call and
# pass parameters into a user function and optionally return something.
# User Function = named block of code.
"""
    DocString:
"""

# Example of a user function with parameter passing
# and defaults, with Annotations (datatype hoping to be passed in).
def say_hello(greeting:str="ciao", recipient:str="amici"):
    message = f"{greeting} {recipient}"
    print(message)
    return None

say_hello("Hiya", "pal") # Positional parameter passing.
say_hello(greeting="bonjour", recipient="mes amis") # Named parameter passing.
say_hello("ni hao", recipient="peng you men") # Mixed parameter passing (positional first)
say_hello(recipient="file mou", greeting="geia sou") # Named parameters in different order.
say_hello("ciao", 'amici')
say_hello()
