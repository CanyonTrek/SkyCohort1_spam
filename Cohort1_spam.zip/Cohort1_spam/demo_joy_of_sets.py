#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to create, grow and shrink
# sets and how to COMBINE them with other SETS (Mutable Unordered Collection)
# Remember Algebra!
"""
    DocString:
"""
# Create two SETS.
marvel_fans = {'donald', 'sam', 'sophie', 'sofia', 'louise'}
dc_fans = set() # Create an empty set!

dc_fans.add('donald')
dc_fans.add('jennifer')
dc_fans.add('jemima')
# dc_fans.pop() # Randomly removes an object.
# comic_fans = marvel_fans.copy() # Copy SET.
# comic_fans.clear() # Empty SET

print(f"Marvel fans = {marvel_fans}")
print(f"DC fans = {dc_fans}")

print("-" * 60)
# Combine SETS using SET operator methods (Rememver VENN diagrams)
print(f"Fans of Marvel or DC = {marvel_fans.union(dc_fans)}")
print(f"Fans of Marvel AND DC = {marvel_fans.intersection(dc_fans)}")
print(f"Fans of ONLY Marvel = {marvel_fans.difference(dc_fans)}")
print(f"Fans of ONLY Marvel OR DC = {marvel_fans.symmetric_difference(dc_fans)}")
print("-" * 60)
# Combine SETS using SET OPERATORS (Rememver VENN diagrams)
print(f"Fans of Marvel or DC = {marvel_fans | dc_fans}")
print(f"Fans of Marvel AND DC = {marvel_fans & dc_fans}")
print(f"Fans of ONLY Marvel = {marvel_fans - dc_fans}")
print(f"Fans of ONLY Marvel OR DC = {marvel_fans ^ dc_fans}")