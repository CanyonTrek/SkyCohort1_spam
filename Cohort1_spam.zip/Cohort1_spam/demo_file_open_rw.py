#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to open/close, and read, write
# and append to a text file.
"""
    DocString:
"""
movies = { 'sam': ['princess diaries', 'star wars', 'matilda'],
           'lidia': ['blue beetle', 'gran turismo', 'avengers end game'],
           'louise': ['spiderman', 'grease', 'sound of music'],
           'donald': ['braveheart', 'brave', 'babe']
}

# Open File Handle for WRITING in TEXT mode.
fh_out = open(r"c:\labs\projects\Cohort1_spam\movies.txt", mode="wt")

# Iterate through movies dict and WRITE key+objects to filehandle.
for name in movies.keys():
    print(f"{name}: {movies[name]}", end="\n")
    fh_out.write(f"{name}: {movies[name]}\n")

# fh_out.flush() # Flush buffers.
fh_out.close() # Flush Buffer and Close file Handle

print("-" * 60)

# Open file handle for READING in TEXT mode.
fh_in = open(r"c:\labs\projects\Cohort1_spam\movies.txt", mode="rt")

# text = fh_in.read() # Read ENTIRE file into str object! Be careful of LARGE files!
# text = fh_in.read(30) # Read NEXT 30 chars into str object!
# text = fh_in.readline() # Read NEXT LINE into str object!
# lines = fh_in.readlines() # Read ENTIRE file into a LIST object! Be careful of LARGE files!
# print(lines[-1]) # Access last line.

# ITERATE through the file handle one line at a time! Memory Efficient!
for line in fh_in:
    print(line, end="")

fh_in.close() # Close file handle.