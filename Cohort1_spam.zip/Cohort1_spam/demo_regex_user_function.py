#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to match lines of data from a
# file using Regular Expressions/Regex and the re.py module.
"""
    DocString:
"""
import re

# Example of a user function with parameter passing and defaults.
def search_pattern(pattern:str=r"^.{19}$", file:str=r"c:\labs\words"):
    lines = 0
    # open file handle for READING in TEXT mode.
    with open(file, mode="rt") as fh_in:
        for line in fh_in:
            m = re.search(pattern, line) # Match lines with at least 5 consecutive vowels.
            if m:
                lines += 1
                print(f"Matched {m.group()} on line {line.rstrip()} at {m.start()}-{m.end()}")

    return lines

search_pattern()
num_lines = search_pattern(r"^([A-Z]).*\1$")
print(f"Number of lines matched = {num_lines}")