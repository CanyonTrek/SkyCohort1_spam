#! /usr/bin/env python3
# Name:        .py
# Author:      Donald Cameron
# Version :    v1.0
# Description: This program will demo how to combine
# separate, but index related sequences using the built-in
# zip() function.
"""
    DocString:
"""
import sys

# Separate but INDEX related sequences.
grads = ['jennifer', 'jemima', 'martin']
fav_bands = ['all time low', 'gastric band', 'bicep']
fav_locs = ['banff', 'amsterdam', 'berlin']
fav_heroes = ['spiderman', 'scarlet witch', 'big ange']

# ITERATE through the sequences and combine the INDEX
# related objects USING an ITERATOR for loop and the built-in
# zip() function.
for (g, fb, fl, fh) in zip(grads, fav_bands, fav_locs, fav_heroes):
    print(g + " likes to listen to " + fb + " in " + fl + " with " + fh)

sys.exit(0) # Explicit exit program with error code (0=success, 1-255=error code)